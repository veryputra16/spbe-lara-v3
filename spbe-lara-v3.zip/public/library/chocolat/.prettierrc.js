module.exports = {
	trailingComma: 'es5',
	tabWidth: 4,
	bracketSpacing: true,
	useTabs: false,
	printWidth: 100,
	semi: false,
	arrowParens: 'always',
	singleQuote: true
}